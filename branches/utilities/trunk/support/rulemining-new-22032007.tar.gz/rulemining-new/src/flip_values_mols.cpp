// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "flip_values_mols.cpp"

// (c) OPAC Team, LIFL, Feb. 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include "flip_values_mols.h"

FlipValuesMOLS :: FlipValuesMOLS (eoEvalFunc <Rule> & __eval
				  ) : eval (__eval) {

}
   
void FlipValuesMOLS :: operator () (const Rule & __rule, moeoArchive <Rule> & __arch) {

  Rule rule = __rule;

  for (unsigned i = 0; i < __rule.size (); i ++) {
    
    Term & term = rule [i];
    
    AttributeKey attr = ATTRIBUTE_KEY(term);
    ValueKey old_value = VALUE_KEY(term);

    for (unsigned j = 0; j < attributes [attr].num_values; j ++) {

      VALUE_KEY(term) = j;
      eval (rule);
      __arch.update (rule);
    }

    VALUE_KEY(term) = old_value;
  }
}
