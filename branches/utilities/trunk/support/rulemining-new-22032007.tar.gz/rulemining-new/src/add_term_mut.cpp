// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "add_term_mut.cpp"

// (c) OPAC Team, LIFL, January 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#include "add_term_mut.h"
#include "valid.h"
#include "mix.h"

bool AddTermMut :: operator () (Rule & __rule) {
 
  std :: vector <bool> sel_attr (num_attributes, false);
    
  for (unsigned i = 0; i < __rule.size (); i ++)
    sel_attr [ATTRIBUTE_KEY(__rule [i])] = true;
  
  std :: vector <AttributeKey> cand_attr;
  
  for (unsigned i = 0; i < num_attributes; i ++)
    if (! sel_attr [i])
      cand_attr.push_back (i);
  
  mix (cand_attr);
  
  if (! cand_attr.empty () && __rule.size () < max_terms) {
    Term term;
    
    ATTRIBUTE_KEY(term) = cand_attr.front ();
    VALUE_KEY(term) = getRandomValueKey (ATTRIBUTE_KEY(term));
    
    __rule.push_back (term);

    validate (__rule);
    
    return true;
  }
  else
    return false;
}
