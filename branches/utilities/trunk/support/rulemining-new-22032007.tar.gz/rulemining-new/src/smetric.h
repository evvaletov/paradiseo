// -*- mode: c++; c-indent-level: 4; c++-member-init-indent: 8; comment-column: 35; -*-

// "smetric.h"

// (c) OPAC Team, LIFL, January 2006

/* This library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2 of the License, or (at your option) any later version.
   
   This library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.
   
   You should have received a copy of the GNU Lesser General Public
   License along with this library; if not, write to the Free Software
   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
   
   Contact: cahon@lifl.fr
*/

#ifndef __smetric_h
#define __smetric_h

#include <vector>

#include <utils/eoUpdater.h>

#include <moeoArchive.h>

#include "rule.h"

typedef std :: vector <double> MOS;

class SmetricUpdater : public eoUpdater {

public :

  SmetricUpdater (moeoArchive <Rule> & __arch,
		  int __rank = -1); 

  void operator () ();

private :

  moeoArchive <Rule> & arch;

 std :: vector <std :: vector <MOS> > list_fronts;

  int rank;
};

#endif
